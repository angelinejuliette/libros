# gestión_libros/inventario.py

class Libro:
    def __init__(self, titulo, autor, cantidad):
        self.titulo = titulo
        self.autor = autor
        self.cantidad = cantidad

    def __str__(self):
        return f"{self.titulo} por {self.autor}, Cantidad: {self.cantidad}"

class Inventario:
    def __init__(self):
        self.libros = []

    def agregar_libro(self, libro):
        self.libros.append(libro)

    def listar_libros(self):
        for libro in self.libros:
            print(libro)

print("Contenido de inventario.py:")
with open(__file__, 'r') as file:
    print(file.read())
