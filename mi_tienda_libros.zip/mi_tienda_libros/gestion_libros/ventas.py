# gestión_libros/ventas.py

from .inventario import Libro

class Venta:
    def __init__(self, libro, cantidad):
        self.libro = libro
        self.cantidad = cantidad

    def procesar_venta(self, inventario):
        for item in inventario.libros:
            if item.titulo == self.libro.titulo and item.autor == self.libro.autor:
                if item.cantidad >= self.cantidad:
                    item.cantidad -= self.cantidad
                    return True
                else:
                    print("No hay suficiente stock para la venta")
                    return False
        print("Libro no encontrado en inventario")
        return False

class RegistroVentas:
    def __init__(self):
        self.ventas = []

    def registrar_venta(self, venta):
        self.ventas.append(venta)

    def total_ventas(self):
        return sum(venta.cantidad for venta in self.ventas)
