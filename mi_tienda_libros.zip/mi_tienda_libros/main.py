# main.py

from gestion_libros.inventario import Libro, Inventario
from gestion_libros.ventas import Venta, RegistroVentas

def mostrar_menu():
    """Muestra el menú principal"""
    print("\n--- Menú de la tienda de libros ---")
    print("1. Agregar libro al inventario")
    print("2. Mostrar inventario")
    print("3. Vender libro")
    print("4. Mostrar total de ventas")
    print("5. Salir")

def agregar_libro(inventario):
    """Agregar un libro al inventario"""
    titulo = input("Ingrese el título del libro: ")
    autor = input("Ingrese el autor del libro: ")
    cantidad = int(input("Ingrese la cantidad del libro: "))
    libro = Libro(titulo, autor, cantidad)
    inventario.agregar_libro(libro)
    print(f"Libro '{titulo}' agregado al inventario.")

def mostrar_inventario(inventario):
    """Mostrar todos los libros en el inventario"""
    print("\nInventario:")
    inventario.listar_libros()

def vender_libro(inventario, registro_ventas):
    """Procesar una venta de un libro"""
    titulo = input("Ingrese el título del libro a vender: ")
    autor = input("Ingrese el autor del libro a vender: ")
    cantidad = int(input("Ingrese la cantidad a vender: "))
    libro_a_vender = Libro(titulo, autor, 0)  # La cantidad no importa aquí
    venta = Venta(libro_a_vender, cantidad)
    if venta.procesar_venta(inventario):
        registro_ventas.registrar_venta(venta)
        print(f"Venta de '{titulo}' procesada.")

def mostrar_total_ventas(registro_ventas):
    """Mostrar el total de ventas"""
    total = registro_ventas.total_ventas()
    print(f"Total de ventas: {total} libros")

def main():
    inventario = Inventario()
    registro_ventas = RegistroVentas()

    while True:
        mostrar_menu()
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            agregar_libro(inventario)
        elif opcion == '2':
            mostrar_inventario(inventario)
        elif opcion == '3':
            vender_libro(inventario, registro_ventas)
        elif opcion == '4':
            mostrar_total_ventas(registro_ventas)
        elif opcion == '5':
            print("Saliendo...")
            break
        else:
            print("Opción no válida. Por favor, intente de nuevo.")

if __name__ == "__main__":
    main()
